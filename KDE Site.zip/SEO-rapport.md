# SEO-rapport (KDE Online persona)

## Gebruikte SEO-tools
1. Google Lighthouse (SEO + Accessibility audits)
2. handmatige controle van `robots.txt` op rootpad (`/robots.txt`)

## Doorgevoerde codeoptimalisaties (minimaal 4)
1. `robots.txt` toegevoegd zodat crawlers de site correct kunnen indexeren.
2. Toegankelijkheidsfout opgelost: menu-knop heeft nu een expliciete toegankelijke naam (`aria-label`).
3. ARIA-structuurfout opgelost: onjuiste `role="menu"` verwijderd waar geen `menuitem`-patroon werd gebruikt.
4. Formuliervelden beter semantisch gemaakt met expliciete koppeling (`for`/`id`) en `name`/`autocomplete`.
5. Externe links verbeterd met `rel="noopener noreferrer"`.
6. Afbeeldingen geoptimaliseerd met `width`, `height`, `loading="lazy"` en `decoding="async"` waar passend.

## Conclusies
- Vindbaarheid is technisch verbeterd doordat crawlers nu een geldige `robots.txt` kunnen ophalen.
- De belangrijkste toegankelijkheidsissues uit Lighthouse zijn opgelost.
- De code is semantischer en efficiënter geworden zonder het ontwerp of de kernfunctionaliteit te wijzigen.

## 2 bruikbare adviezen over vindbaarheid
1. Publiceer een XML-sitemap en dien deze in bij Google Search Console en Bing Webmaster Tools.
2. Voeg per pagina een canonieke URL (`<link rel="canonical">`) toe zodra het definitieve domein bekend is.
